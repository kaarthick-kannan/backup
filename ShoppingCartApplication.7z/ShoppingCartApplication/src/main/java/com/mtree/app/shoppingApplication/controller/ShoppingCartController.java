package com.mtree.app.shoppingApplication.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.mtree.app.shoppingApplication.dto.Customer;
import com.mtree.app.shoppingApplication.entitiy.Cart;
import com.mtree.app.shoppingApplication.entitiy.Product;
import com.mtree.app.shoppingApplication.entitiy.TakenProduct;
import com.mtree.app.shoppingApplication.entitiy.User;
import com.mtree.app.shoppingApplication.service.ProductService;
import com.mtree.app.shoppingApplication.service.UserService;
import com.mtree.app.shoppingApplication.utility.ShoppingCartUtility;

@Controller
@SessionAttributes("customer")
public class ShoppingCartController {

	@Autowired
	HttpSession session;

	@Autowired
	private ProductService productService;

	@Autowired
	private UserService userService;

	private static final Logger logger = LoggerFactory.getLogger(ShoppingCartController.class);

	@RequestMapping("/")
	public String viewLoginPage(Model model) {
		model.addAttribute("customer", new Customer());
		logger.info("Application Started");
		return "index";
	}

	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public String addUserAndCart(@ModelAttribute("customer") Customer customer, Model model) {
		User user = null;
		if (customer != null) {
			user = userService.addUser(customer.getName(), customer.getPhoneNumber());
			customer.setUserId(user.getId());
			customer.setCartId(user.getCart().getId().toString());
		} else {
			logger.error("Customer data is not recieved");
			model.addAttribute("ErrorMessage", "Customer Data is not recieved, Please try again");
			model.addAttribute("customer", new Customer());
			return "index";
		}
		return "redirect:/cart";
	}

	@RequestMapping(value = "/viewProducts", method = RequestMethod.GET)
	public String listAllProducts(Model model) {
		Collection<Product> products = productService.getAllProducts();
		model.addAttribute("selectedProduct", new Product());
		model.addAttribute("listProducts", products);
		logger.info("VAbout to view all products");
		return "Shop";
	}

	@RequestMapping(value = "/findByID/{productId}", method = RequestMethod.GET)
	public String findProductById(@PathVariable("productId") String productId, Model model) {
		model.addAttribute("selectedProduct", new Product());
		Product product = null;
		try {
			product = productService.getSingleProduct(productId);
		} catch (IllegalArgumentException e) {
			logger.error("Error Occured wile getting product by ID", e);
			model.addAttribute("ErrorMessage", "Invalid Data Entered in productId field");
			model.addAttribute("listProducts", productService.getAllProducts());
			return "shop";
		}
		if (product != null) {
			model.addAttribute("listProducts", product);
		} else {
			logger.info("No Data found for given product Id");
			model.addAttribute("listProducts", productService.getAllProducts());
			model.addAttribute("ErrorMessage", "No Data found for given productID: " + productId);
		}
		return "shop";
	}

	@RequestMapping(value = "/findByName/{productName}", method = RequestMethod.GET)
	public String findProductByName(@PathVariable("productName") String productName, Model model) {
		model.addAttribute("selectedProduct", new Product());
		Collection<Product> products = null;
		try {
			products = productService.getProductsByName(productName);
		} catch (IllegalArgumentException e) {
			logger.error("Error Occured wile getting product by Name", e);
			model.addAttribute("ErrorMessage", "Invalid Data Entered in productName field");
			model.addAttribute("listProducts", productService.getAllProducts());
			return "shop";
		}
		if (!CollectionUtils.isEmpty(products)) {
			model.addAttribute("listProducts", products);
		} else {
			logger.info("No Data found for given product Name");
			model.addAttribute("listProducts", productService.getAllProducts());
			model.addAttribute("ErrorMessage", "No Data found for given product name: " + productName);
		}
		return "shop";
	}

	@RequestMapping(value = "/findByCategory/{productCategory}", method = RequestMethod.GET)
	public String findProductByCategory(@PathVariable("productCategory") String productCategory, Model model) {
		Collection<Product> products = productService.getProductsByCategory(productCategory);
		model.addAttribute("selectedProduct", new Product());
		if (!CollectionUtils.isEmpty(products)) {
			model.addAttribute("listProducts", products);
		} else {
			logger.info("No Data found for given product category");
			model.addAttribute("listProducts", productService.getAllProducts());
			model.addAttribute("ErrorMessage", "No Data found for given category: " + productCategory);
		}
		return "Shop";
	}

	@RequestMapping(value = "/cart", method = RequestMethod.GET)
	public String viewCartPage(Model model) {
		Customer customer = (Customer) session.getAttribute("customer");
		User user = userService.getUserByPhoneNumber(customer.getPhoneNumber());
		if (user != null && user.getCart() != null) {
			Collection<TakenProduct> takenProducts = user.getCart().getTakenProducts();
			model.addAttribute("selectedTakenProduct", new TakenProduct());
			model.addAttribute("listTakenProducts", takenProducts);
			model.addAttribute("total", user.getCart().getTotalPrice());
			logger.info("Cart About to be Viewed");
		}
		return "cart";
	}

	@RequestMapping(value = "/addToCart", method = RequestMethod.POST)
	public String addToCart(Model model, @ModelAttribute("selectedProduct") Product product) {
		TakenProduct selectedProduct = new TakenProduct();
		selectedProduct = ShoppingCartUtility.productMaper(product);
		selectedProduct.setQuantity(1);
		Customer customer = (Customer) session.getAttribute("customer");
		User user= userService.getUserByPhoneNumber(customer.getPhoneNumber());
		Cart cart = user.getCart();
		if (cart != null) {
			if (cart.getTakenProducts().contains(selectedProduct)) {
				for (TakenProduct takenProductsItr : cart.getTakenProducts()) {
					if (takenProductsItr.equals(selectedProduct)) {
						if (takenProductsItr.getQuantity() < product.getUnitsPresent()) {
							takenProductsItr.setQuantity(takenProductsItr.getQuantity() + 1);
							cart.setTotalPrice(cart.getTotalPrice() + selectedProduct.getPrice());
						} else {
							model.addAttribute("ErrorMessage", "Maximum quantity of " + product.getProductName()
									+ " available in store is added already");
							model.addAttribute("selectedProduct", new Product());
							model.addAttribute("listProducts", productService.getAllProducts());
							logger.info("Maximum quantity of " + product.getProductName()
									+ " available in store is added already");
							return "Shop";
						}
					}
				}
			} else {
				cart.getTakenProducts().add(selectedProduct);
				cart.setTotalPrice(cart.getTotalPrice() + selectedProduct.getPrice());
			}
			userService.updateUser(user);
			logger.info("cart updated");
		}
		return "redirect:/cart";
	}

	@RequestMapping(value = "/updateInCart", method = RequestMethod.PUT)
	public String updateProductInCart(Model model, @ModelAttribute("selectedTakenProduct") TakenProduct takenProduct) {
		if (takenProduct != null) {
			Customer customer = (Customer) session.getAttribute("customer");
			User user = userService.getUserById(customer.getUserId());
			Cart cart = user.getCart();
			if (cart != null) {
				Product product = productService.getSingleProduct(takenProduct.getProductId());
				Iterator<TakenProduct> itr = cart.getTakenProducts().iterator();
				while (itr.hasNext()) {
					TakenProduct takenProductItr = itr.next();
					if (takenProductItr.equals(takenProduct)) {
						if (takenProduct.getQuantity() <= product.getUnitsPresent() && takenProduct.getQuantity() > 0) {
							cart.setTotalPrice(cart.getTotalPrice() - takenProductItr.getTotalPrice());
							takenProductItr.setQuantity(takenProduct.getQuantity());
							takenProductItr.setTotalPrice((takenProduct.getQuantity()) * (takenProductItr.getPrice()));
							cart.setTotalPrice(cart.getTotalPrice() + takenProductItr.getTotalPrice());
						} else if (takenProduct.getQuantity() == 0) {
							itr.remove();
							cart.setTotalPrice(cart.getTotalPrice() - takenProductItr.getTotalPrice());
						} else {
							model.addAttribute("ErrorMessage",
									"Quantity entered exeeds the count available in inventory, Please check below");
							model.addAttribute("selectedProduct", new Product());
							model.addAttribute("listProducts", productService.getAllProducts());
							logger.info("No entered quantity vailable in the store in update cart operation");
							return "Shop";
						}
					}
				}
				userService.updateUser(user);
			}
		}
		return "redirect:/cart";
	}

	@RequestMapping(value = "/deleteUnitInCart/{takenProductId}", method = RequestMethod.GET)
	public String deleteSingleUnit(@PathVariable("takenProductId") String takenProductId) {
		Customer customer = (Customer) session.getAttribute("customer");
		userService.deleteSingleTakenProduct(customer.getUserId(), takenProductId);
		return "redirect:/cart";
	}

	@RequestMapping(value = "/clearCart/{userId}", method = RequestMethod.GET)
	public String clearCart(@PathVariable("userId") String userId) {
		userService.clearUserCart(userId);
		return "redirect:/cart";
	}
}
