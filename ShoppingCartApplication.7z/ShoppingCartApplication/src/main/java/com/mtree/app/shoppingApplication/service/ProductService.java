package com.mtree.app.shoppingApplication.service;

import java.util.Collection;
import java.util.List;

import com.mtree.app.shoppingApplication.entitiy.Product;

public interface ProductService {


	public Collection<Product> getAllProducts();

	public List<Product> addAllProducts(Collection<Product> products);

	public Product getSingleProduct(String id) ;

	public Collection<Product> getProductsByName(String name);

	public Collection<Product> getProductsByCategory(String name) ;
	
	public void reduceProductFromStore(String productId);
}
