package com.mtree.app.shoppingApplication.utility;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.thymeleaf.util.StringUtils;

public class ValidationUtility {
	
	private static final Logger logger = LoggerFactory.getLogger(ValidationUtility.class);

	public static void nullAndEmptyCheckValidation(String field) throws IllegalArgumentException {
		if (StringUtils.isEmptyOrWhitespace(field)) {
			logger.error("Invalid arguments entered");
			throw new IllegalArgumentException("Entered " + field + " data is Invalid, Please Enter Proper Data");
		}
	}

	public static void nullAndEmptyCheckValidation(String fieldOne, String fieldTwo) throws IllegalArgumentException {
		if (StringUtils.isEmptyOrWhitespace(fieldOne) && StringUtils.isEmptyOrWhitespace(fieldTwo)) {
			logger.error("Invalid arguments entered");
			throw new IllegalArgumentException(
					"Entered " + fieldOne + " and " + fieldTwo + " data are Invalid, Please Enter Valid Datas");
		}
	}
}
