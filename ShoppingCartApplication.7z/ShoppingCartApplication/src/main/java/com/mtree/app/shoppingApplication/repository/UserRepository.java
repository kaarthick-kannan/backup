package com.mtree.app.shoppingApplication.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.mtree.app.shoppingApplication.entitiy.User;

@Repository
public interface UserRepository extends MongoRepository<User,String>{

	Optional<User> findByPhoneNumber(String phoneNumber);

}
