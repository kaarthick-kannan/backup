package com.mtree.app.shoppingApplication.service;

import com.mtree.app.shoppingApplication.entitiy.User;

public interface UserService {
	
	public User addUser(String name, String phoneNumber);

	public User getUserByPhoneNumber(String phoneNumber);
	
	public User getUserById(String id);
	
	public User updateUser(User user);

	public void deleteSingleTakenProduct(String userId, String takenProductId);

	public void clearUserCart(String userId);
	

}
