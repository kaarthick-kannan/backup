package com.mtree.app.shoppingApplication.repository;

import java.util.Collection;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.mtree.app.shoppingApplication.entitiy.Product;



@Repository
public interface ProductRepository extends MongoRepository<Product, String>{

	Optional<Collection<Product>> findByProductName(String productName);
	
	Optional<Collection<Product>> findBycategory(String category);
}
