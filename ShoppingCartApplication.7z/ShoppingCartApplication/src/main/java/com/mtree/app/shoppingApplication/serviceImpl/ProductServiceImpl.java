package com.mtree.app.shoppingApplication.serviceImpl;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mtree.app.shoppingApplication.entitiy.Product;
import com.mtree.app.shoppingApplication.repository.ProductRepository;
import com.mtree.app.shoppingApplication.service.ProductService;
import com.mtree.app.shoppingApplication.utility.ShoppingCartUtility;
import com.mtree.app.shoppingApplication.utility.ValidationUtility;

@Service
@Transactional(readOnly = true)
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private ShoppingCartUtility shoppingCartUtility;

	private static final Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);

	public Collection<Product> getAllProducts() {
		logger.info("About to retrieve all products");
		return productRepository.findAll();
	}

	@Transactional
	public List<Product> addAllProducts(Collection<Product> products) {
		logger.info("About to save all products");
		return productRepository.saveAll(products);
	}

	public Product getSingleProduct(String id) {
		ValidationUtility.nullAndEmptyCheckValidation(id);
		Optional<Product> foundProduct = productRepository.findById(id);
		if (foundProduct.isPresent()) {
			logger.info("product found");
			return foundProduct.get();
		} else {
			return null;
		}
	}

	public Collection<Product> getProductsByName(String name) {
		ValidationUtility.nullAndEmptyCheckValidation(name);
		Optional<Collection<Product>> foundProducts = productRepository.findByProductName(name);
		if (foundProducts.isPresent()) {
			logger.info("product found by name");
			return foundProducts.get();
		} else {
			return null;
		}
	}

	public Collection<Product> getProductsByCategory(String name) {
		Optional<Collection<Product>> foundProducts = productRepository.findBycategory(name);
		if (foundProducts.isPresent()) {
			logger.info("product found by category");
			return foundProducts.get();
		} else {
			return null;
		}
	}

	@Transactional
	public void reduceProductFromStore(String productId) {
		Product product = getSingleProduct(productId);
		if (product.getUnitsPresent() == 1) {
			productRepository.deleteById(productId);
		} else {
			product.setUnitsPresent(product.getUnitsPresent() - 1);
			productRepository.save(product);
		}
		logger.info("reducted product from store");
	}

	@PostConstruct
	public void init() {
		Collection<Product> products = shoppingCartUtility.populateAllBooksAndApparals();
		productRepository.deleteAll();
		logger.info("Deleted all products");
		addAllProducts(products);
		logger.info("Added all products");
	}

	@PreDestroy
	public void destroy() {
		productRepository.deleteAll();
		logger.info("deleted all products");
	}

}
