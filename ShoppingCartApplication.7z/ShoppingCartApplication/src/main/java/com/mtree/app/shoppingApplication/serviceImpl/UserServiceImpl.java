package com.mtree.app.shoppingApplication.serviceImpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mtree.app.shoppingApplication.entitiy.Cart;
import com.mtree.app.shoppingApplication.entitiy.TakenProduct;
import com.mtree.app.shoppingApplication.entitiy.User;
import com.mtree.app.shoppingApplication.repository.UserRepository;
import com.mtree.app.shoppingApplication.service.UserService;
import com.mtree.app.shoppingApplication.utility.ValidationUtility;

@Service
@Transactional(readOnly = true)
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

	@Transactional
	public User addUser(String name, String phoneNumber) {
		ValidationUtility.nullAndEmptyCheckValidation(name);
		User retrievedUser = getUserByPhoneNumber(phoneNumber);
		if (retrievedUser != null) {
			logger.info("user already present, retrieved user details");
			return retrievedUser;
		} else {
			User user = new User();
			user.setName(name);
			user.setPhoneNumber(phoneNumber);
			user.setCart(new Cart());
			logger.info("New user is about to be added");
			return userRepository.insert(user);
		}
	}

	public User getUserByPhoneNumber(String phoneNumber) {
		Optional<User> optionalUser = userRepository.findByPhoneNumber(phoneNumber);
		if (optionalUser.isPresent()) {
			logger.info("user found by phone number");
			User user = optionalUser.get();
			return user;
		} else {
			return null;
		}
	}

	public User getUserById(String id) {
		Optional<User> optionalUser = userRepository.findById(id);
		if (optionalUser.isPresent()) {
			logger.info("user found by Id");
			User user = optionalUser.get();
			return user;
		} else {
			return null;
		}
	}

	@Transactional
	public User updateUser(User user) {
		logger.info("cart about to be saved");
		return userRepository.save(user);
	}

	@Override
	public void deleteSingleTakenProduct(String userId, String takenProductId) {
		User user = getUserById(userId);
		Cart cart = user.getCart();
		if (cart != null) {
			Iterator<TakenProduct> itr = cart.getTakenProducts().iterator();
			while (itr.hasNext()) {
				TakenProduct takenProductItr = itr.next();
				if (takenProductItr.getId().equals(takenProductId)) {
					if (takenProductItr.getQuantity() > 1) {
						takenProductItr.setQuantity(takenProductItr.getQuantity() - 1);
						cart.setTotalPrice(cart.getTotalPrice() - takenProductItr.getPrice());
					} else if (takenProductItr.getQuantity() == 1) {
						itr.remove();
						cart.setTotalPrice(cart.getTotalPrice() - takenProductItr.getPrice());
					}
				}
			}
			userRepository.save(user);
			logger.info("Deletion is successful");
		}
	}

	@Override
	public void clearUserCart(String userId) {
		User user = getUserById(userId);
		Cart cart = user.getCart();
		if (cart != null) {
			cart.setTakenProducts(new ArrayList<>());
			cart.setTotalPrice(0);
			userRepository.save(user);
			logger.info("Cart has been cleared");
		}
	}
}
