package com.mtree.app.shoppingApplication.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.ui.Model;
import org.springframework.web.HttpSessionRequiredException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.mtree.app.shoppingApplication.dto.Customer;

@ControllerAdvice
public class GlobalExceptionHandler {
	private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	@ExceptionHandler(HttpSessionRequiredException.class)
	private String handle(Model model, HttpSessionRequiredException exception) {
		logger.info("session Resetted", exception);
		return "redirect:/";
	}

	@ExceptionHandler(IncorrectResultSizeDataAccessException.class)
	private String handle(Model model, IncorrectResultSizeDataAccessException exception) {
		model.addAttribute("ErrorMessage", "Data Entered is not unique adn already exists");
		model.addAttribute("customer", new Customer());
		logger.info("Retrieve Operation returned non unique Result", exception);
		return "index";
	}

	@ExceptionHandler(IllegalStateException.class)
	private String handle(Model model, IllegalStateException exception) {
		model.addAttribute("ErrorMessage", "Facing Issues in our Side, Please Try Later");
		logger.error("Cannot able to connect to database Connection timed out", exception);
		return "index";
	}

	@ExceptionHandler(Exception.class)
	private String handle(Model model, Exception exception) {
		model.addAttribute("ErrorMessage", "Something went wrong, Please Try Again");
		logger.error("Something went wrong", exception);
		return "index";
	}
}
