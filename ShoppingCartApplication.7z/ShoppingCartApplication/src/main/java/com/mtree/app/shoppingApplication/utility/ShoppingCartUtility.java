package com.mtree.app.shoppingApplication.utility;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeMap;
import org.springframework.stereotype.Component;

import com.mtree.app.shoppingApplication.entitiy.Apparal;
import com.mtree.app.shoppingApplication.entitiy.Book;
import com.mtree.app.shoppingApplication.entitiy.Product;
import com.mtree.app.shoppingApplication.entitiy.TakenProduct;

@Component
public class ShoppingCartUtility {

	public Collection<Product> populateAllBooksAndApparals(){
		List<Product> products=new ArrayList<>();
		Book product1= new Book();
		product1.setPrice(20);
		product1.setProductName("harry potter");
		product1.setAuthor("JK Rowling");
		product1.setUnitsPresent(7);
		product1.setPublications("Harry Potter");
		product1.setGenre("Fantasy");
		product1.setCategory("book");
		products.add(product1);
		
		
		Book product2= new Book();
		product2.setPrice(30);
		product2.setProductName("mein kemph");
		product2.setAuthor("Adolf Hitler");
		product2.setUnitsPresent(2);
		product2.setPublications("Mein Kemph");
		product2.setGenre("Biography");
		product2.setCategory("book");
		products.add(product2);
		
		Book product3= new Book();
		product3.setPrice(40);
		product3.setProductName("steve jobs");
		product3.setAuthor("Drew L.Crichton");
		product3.setUnitsPresent(8);
		product3.setPublications("unkown");
		product3.setGenre("Biography");
		product3.setCategory("book");
		products.add(product3);
		
		Book product4= new Book();
		product4.setPrice(50);
		product4.setProductName("edison");
		product4.setAuthor("Matthew Josephson");
		product4.setUnitsPresent(12);
		product4.setPublications("unknown");
		product4.setGenre("biography");
		product4.setCategory("book");
		products.add(product4);
		
		Apparal apparal1=new Apparal();
		apparal1.setBrand("trends");
		apparal1.setDesign("Patiala");
		apparal1.setPrice(300);
		apparal1.setProductName("trends women's pants");
		apparal1.setType("cotton");
		apparal1.setUnitsPresent(5);
		apparal1.setCategory("apparal");
		products.add(apparal1);
	
		Apparal apparal2=new Apparal();
		apparal2.setBrand("Printopus");
		apparal2.setDesign("T-Shirt");
		apparal2.setPrice(350);
		apparal2.setProductName("ps women's t-shirt");
		apparal2.setType("Cotton");
		apparal2.setUnitsPresent(8);
		apparal2.setCategory("apparal");
		products.add(apparal2);
		
		Apparal apparal3=new Apparal();
		apparal3.setBrand("Levis");
		apparal3.setDesign("Slim Fit");
		apparal3.setPrice(700);
		apparal3.setProductName("levis women's denim Jeans");
		apparal3.setType("Denim");
		apparal3.setUnitsPresent(4);
		apparal3.setCategory("apparal");
		products.add(apparal3);
		
		Apparal apparal4=new Apparal();
		apparal4.setBrand("Kappa");
		apparal4.setDesign("collered");
		apparal4.setPrice(400);
		apparal4.setProductName("kapppa t-shirts");
		apparal4.setType("Cotton");
		apparal4.setUnitsPresent(8);
		apparal4.setCategory("apparal");
		products.add(apparal4);
		
		Apparal apparal5=new Apparal();
		apparal5.setBrand("Bata");
		apparal5.setDesign("High heels");
		apparal5.setPrice(900);
		apparal5.setProductName("sandals");
		apparal5.setType("Leather");
		apparal5.setUnitsPresent(3);
		apparal5.setCategory("apparal");
		products.add(apparal5);
		
		return products;
	}
	
	
public static TakenProduct productMaper(Product product){
	ModelMapper modelMapper=new ModelMapper();
	TypeMap<Product, TakenProduct> typeMap = 
		    modelMapper.createTypeMap(Product.class, TakenProduct.class);
	typeMap.addMappings(mapper -> {
		mapper.map(src -> src.getId(),
				TakenProduct::setId);
		mapper.map(src -> src.getProductName(),
				TakenProduct::setProductName);
		mapper.map(src -> src.getPrice(),
				TakenProduct::setPrice);
		});
	return modelMapper.map(product, TakenProduct.class);
}
	
	
}
