package com.mtree.app.shoppingApplication.entitiy;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonProperty;

@Document
public class Product implements Comparable<Product> {
	@Id
	@JsonProperty("_id")
	private String id;
	private String productName;
	private double price;
	private int unitsPresent;
	private String category;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getUnitsPresent() {
		return unitsPresent;
	}

	public void setUnitsPresent(int unitsPresent) {
		this.unitsPresent = unitsPresent;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", productName=" + productName + ", price=" + price + ", unitsPresent="
				+ unitsPresent + "]";
	}

	@Override
	public int compareTo(Product o) {
		return productName.compareTo(o.getProductName());
	}

}
